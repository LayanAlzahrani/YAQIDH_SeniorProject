package com.example.yaqidh_first

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
